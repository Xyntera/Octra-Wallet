package com.example.ouqro_wallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
